package com.example.jwt.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
	@Value("${jwt.secret}")
	private String secret;
	
	@GetMapping("testProfile")
	public String getProfileName(){
		
		return secret;
	}
	
}
