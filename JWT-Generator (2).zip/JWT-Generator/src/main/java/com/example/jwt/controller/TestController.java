package com.example.jwt.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.jwt.model.JwtRequest;
import com.example.jwt.model.JwtResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class TestController {

	
}
